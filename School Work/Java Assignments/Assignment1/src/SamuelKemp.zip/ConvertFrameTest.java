import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;

public class ConvertFrameTest
{   public static void main(String args[])
    {

        ConvertFrame frame = new ConvertFrame();
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(550, 180);
        frame.setVisible(true);

    }


}
