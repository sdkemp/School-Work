abstract class Vehicle
{

    //abstract method
    abstract double GetCarbonFootprint();
}
