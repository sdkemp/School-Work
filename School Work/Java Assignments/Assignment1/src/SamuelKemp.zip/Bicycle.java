public class Bicycle extends Vehicle
{
    //carbonfoot print
    @Override
    double GetCarbonFootprint() {
        return 0;
    }
}
